# Shipping Department Ops Hub
**Eagle Grove, IA · 3183 HWY 17**

A static website for the shipping department — hosting shift reports, SOPs, KPIs, role standards, announcements, and team contacts. Built to run free on GitHub Pages.

---

## 🚀 How to Deploy to GitHub Pages (Free)

1. **Create a GitHub account** at [github.com](https://github.com) if you don't have one.

2. **Create a new repository**:
   - Click the `+` icon → "New repository"
   - Name it: `shipping-hub` (or anything you like)
   - Set to **Public** (required for free GitHub Pages)
   - Click "Create repository"

3. **Upload your files**:
   - Click "uploading an existing file"
   - Drag in ALL files from this folder (maintain the folder structure: `css/`, `js/`, `pages/`)
   - Commit the files

4. **Enable GitHub Pages**:
   - Go to your repo → Settings → Pages
   - Under "Source" select: **Deploy from a branch**
   - Branch: `main` · Folder: `/ (root)`
   - Click Save

5. **Your site goes live** at:
   `https://YOUR-USERNAME.github.io/shipping-hub/`

   *(Takes 1–2 minutes after first deploy)*

---

## 📝 How to Update Content

### Add an Announcement
Open `pages/announcements.html` on GitHub (click the file → pencil icon to edit).
Copy an existing `.announce-card` block and paste it at the top. Change the date, title, and text.

**Card types:**
- `.announce-card` — standard (amber left border)
- `.announce-card.urgent` — urgent (red left border)
- `.announce-card.info` — informational (blue left border)

### Update KPI Numbers
Open `pages/kpi.html` and find the `<div class="kpi-value" data-editable="...">` tags. Change the number between the tags.

> **Tip:** You can also click KPI values directly on the live site to edit them in your browser (they save locally — not shared across computers). For shared edits, update the HTML on GitHub.

### Add a New SOP
Open `pages/sops.html`. Find the tab you want to add to. Copy an existing `.sop-item` + `.sop-expanded` block pair and update:
- `SOP-S0X` number
- Title and description
- The steps inside the `<ol class="step-list">`

### Update Team Contacts
Open `pages/contacts.html`. Replace every `[Name]`, `[Phone]`, and `[Email]` placeholder with real info.

### Add a New Page
1. Copy any existing page in `pages/`
2. Rename it (e.g., `pages/carriers.html`)
3. Update the content
4. Add a link to it in the `<nav class="main-nav">` section of every page

---

## 📺 TV / Screen Display Mode (KPI Board)

On the KPI Board page, click **TV MODE** to switch to a full-screen display optimized for a wall-mounted TV or monitor. 

- Shows a large clock, date, and current shift
- Hides navigation and form elements
- Press **Escape** or click **EXIT TV MODE** to return

---

## 📁 File Structure

```
shipping-hub/
├── index.html              ← Homepage / hub
├── css/
│   └── main.css            ← All styles
├── js/
│   └── main.js             ← Clock, shift detection, editable KPIs
└── pages/
    ├── kpi.html            ← KPI Board (with TV Mode)
    ├── shift-reports.html  ← Shift handoff report form + log
    ├── sops.html           ← SOPs by category (tabbed)
    ├── roles.html          ← Role standards (Supervisor, Lead, Clerk)
    ├── announcements.html  ← Team announcements
    └── contacts.html       ← Team directory
```

---

## 🔮 Future Additions (Easy to Add)

- **Carrier Tracker** — a page listing carrier performance and contact info
- **Training Library** — link to how-to videos or uploaded guides
- **Policy Archive** — older announcements and deprecated SOPs
- **Shift Calendar** — embed a Google Calendar showing shift schedules
- **Google Forms Integration** — link the shift report form to a real Google Form so data is captured in a spreadsheet automatically

---

*Built for the Shipping Department · Eagle Grove, IA*
